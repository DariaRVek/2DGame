import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import game2D.*;

/**
 * @author 2118616
 * 
 * The starting point of the game. Presents user with a
 * "Level Select" screen from which user can choose to 
 * play Level 1 or Level 2. 
 */
@SuppressWarnings("serial")
public class MainMenu extends GameCore {
	
	static int screenWidth = 750;
	static int screenHeight = 595;
	TileMap tmapHome = new TileMap();
	boolean button1Clicked = false, button2Clicked = false;
	
	Animation logoAnim, levelSelectAnim, button1Anim, button1PressAnim, button2Anim, button2PressAnim;
	Sprite logo, levelSelect, button1, button1Press, button2, button2Press;
	ArrayList<Sprite> buttons = new ArrayList<Sprite>();
	
	/**
	 * Constructor method to initialise the menu.
	 */
	public MainMenu() {
		initMenuInterface();
        // Start in windowed mode with the given screen height and width
        run(false,screenWidth,screenHeight);
	}//end constructor method
	
	/**
	 * Method to initialise the menu.
	 * Adds various buttons and images to the menu.
	 */
	public void initMenuInterface() {
		tmapHome.loadMap("maps/lvl0_home", "lvl0_home.txt");
		setSize(tmapHome.getPixelWidth()+25, tmapHome.getPixelHeight()+25);
		setVisible(true);
		
		button1Anim = new Animation();
		button1Anim.addFrame(loadImage("images/ui/btn1.png"), 1000);
		button1 = new Sprite(button1Anim);
		button1.setPosition(screenWidth/3, screenHeight/5+150);
		button1.show();
		
		button1PressAnim = new Animation();
		button1PressAnim.addFrame(loadImage("images/ui/btn1press.png"), 1000);
		
		button2Anim = new Animation();
		button2Anim.addFrame(loadImage("images/ui/btn2.png"), 1000);
		button2 = new Sprite(button2Anim);
		button2.setPosition((screenWidth/3)+50, screenHeight/5+150);
		button2.show();
		
		button2PressAnim = new Animation();
		button2PressAnim.addFrame(loadImage("images/ui/btn2press.png"), 1000);	
		
		levelSelectAnim = new Animation();
		levelSelectAnim.addFrame(loadImage("images/ui/header.png"), 1000);
		levelSelect = new Sprite(levelSelectAnim);
		levelSelect.setPosition((screenWidth/3)-100, (screenHeight/5)-50);
		levelSelect.show();
		
		logoAnim = new Animation();
		logoAnim.addFrame(loadImage("images/ui/fox RUN(3).png"), 1000);
		logo = new Sprite(logoAnim);
		logo.setPosition(0, screenHeight-50);
		logo.show();
		
		System.out.println(tmapHome);
		setLocationRelativeTo(null);
	}//end method initMenuInterface

	@Override
	 /**
     * Draw the current state of the game. Note the sample use of
     * debugging output that is drawn directly to the game screen.
     */
    public void draw(Graphics2D g) {    

        int xo = 0;
        int yo = 10;

        g.setColor(Color.white);
        g.fillRect(0, 0, getWidth(), getHeight());

        // Apply offsets to tile map and draw  it
        tmapHome.draw(g,xo,yo); 
        
        button1.setOffsets(xo, yo);
        button1.draw(g);
        
        button2.setOffsets(xo, yo);
        button2.draw(g);
        
        levelSelect.setOffsets(xo, yo);
        levelSelect.draw(g);
        
        logo.setOffsets(xo, yo);
        logo.draw(g);
    }//end method draw
	
	/**
	 * Method to override update method in GameCore.java.
	 * Method will update state of the game and/or animations
	 * based on the amount of elapsed time that has passed.
	 * This method controls what specific Level is constructed
	 * dependent on what button the user clicks on.
	 */
	public void update(long elapsed) {
		if(button1Clicked) {
			this.dispose();
			Level1 levelOne = new Level1();
		} else if (button2Clicked) {
			this.dispose();
			Level2 levelTwo = new Level2();
		}//end if else if
	}//end method update
	
	/**
	 * Handler for the mouseReleased event.
	 * Converts coordinates of user's click to a Point.
	 * Converts bounds of each button to a Rectangle.
	 * Evaluates if Point is within one of these Rectangles
	 * and changes animation if it is.
	 * 
	 * @param e the mouse release.
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		int mouseClickX = e.getX();
		int mouseClickY = e.getY();
		Point click = new Point(mouseClickX, mouseClickY);
		Rectangle button1Rect = getB1Rect();
		Rectangle button2Rect = getB2Rect();
		if(button1Rect.contains(click)) button1.setAnimation(button1Anim);
		else if (button2Rect.contains(click)) button2.setAnimation(button2Anim);
	}//end method mouseReleased
	
	/**
	 * Handler for the mousePressed event.
	 * Converts coordinates of user's click to a Point.
	 * Converts bounds of each button to a Rectangle.
	 * Evaluates if Point is within one of these Rectangles
	 * and changes animation if it is.
	 * 
	 * @param e the mouse press.
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		int mouseClickX = e.getX();
		int mouseClickY = e.getY();
		Point click = new Point(mouseClickX, mouseClickY);
		Rectangle button1Rect = getB1Rect();
		Rectangle button2Rect = getB2Rect();
		if(button1Rect.contains(click)) button1.setAnimation(button1PressAnim);
		else if (button2Rect.contains(click)) button2.setAnimation(button2PressAnim);
	}//end method mousePressed
	
	/**
	 * Handler for the mouseClicked event.
	 * Converts coordinates of user's click to a Point.
	 * Converts bounds of each button to a Rectangle.
	 * Evaluates if Point is within one of these Rectangles
	 * and flips relevant boolean flag to true if it is.
	 * Boolean flag used to control a level being constructed.
	 * 
	 * @param e the mouse click.
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		int mouseClickX = e.getX();
		int mouseClickY = e.getY();
		Point click = new Point(mouseClickX, mouseClickY);
		Rectangle button1Rect = getB1Rect();
		Rectangle button2Rect = getB2Rect();
		if(button1Rect.contains(click)) button1Clicked = true;
		else if (button2Rect.contains(click)) button2Clicked = true;
	}//end method mouseClicked
	
	/**
	 * Method to return the Rectangle representing button for Level1.
	 * 
	 * @return a Rectangle representing bounds of button1.
	 */
	public Rectangle getB1Rect() {
		return getRect((int)button1.getX(), (int)button1.getY(), button1.getWidth(), button1.getHeight());
	}//end method getB1Rect
	
	/**
	 * Method to return the Rectangle representing button for Level2.
	 * 
	 * @return a Rectangle representing bounds of button2.
	 */
	public Rectangle getB2Rect() {
		return getRect((int)button2.getX(), (int)button2.getY(), button2.getWidth(), button2.getHeight());
	}//end method getB2Rect
	
	/**
	 * Method to return a new Rectangle using x, y, width, and height.
	 * 
	 * @return a new Rectangle.
	 */
	public Rectangle getRect(int x, int y, int width, int height) {
		return new Rectangle(x, y, width, height);
	}//end method getRect

}//end class MainMenu

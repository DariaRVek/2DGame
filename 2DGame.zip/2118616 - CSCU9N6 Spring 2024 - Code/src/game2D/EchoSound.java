package game2D;

import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Class to apply an echo filter to a sound
 */
public class EchoSound extends FilterInputStream {
	
	/**
	 * Constructor method.
	 * 
	 * @param in the stream of bytes
	 */
	EchoSound(InputStream in) { super(in); }

	/**
	 * Method taken from practical 5.
	 * Retrieves a value in buffer (byte array) at a given position (int).
	 * Converts value to short big-endian format.
	 * 
	 * @param buffer the byte array containing sound sample.
	 * @param position the position in buffer to retrieve sample from.
	 * @return value in buffer in short big-endian format.
	 */
	public short getSample(byte[] buffer, int position) {
		return (short) (((buffer[position+1] & 0xff) << 8) |
					     (buffer[position] & 0xff));
	}//end method getSample

	/**
	 * Method taken from practical 5.
	 * Sets sample (short) in buffer (byte array) at given position
	 * (int) in little-endian format.
	 * 
	 * @param buffer the byte array containing sound sample.
	 * @param position the position in buffer to set sample to.
	 * @param sample the sample to set.
	 */
	public void setSample(byte[] buffer, int position, short sample) {
		buffer[position] = (byte)(sample & 0xFF);
		buffer[position+1] = (byte)((sample >> 8) & 0xFF);
	}//end method setSample

	/**
	 * Method to iterate through a given sample and calculate echoed (short) value.
	 * Inserts echoed value back into sample (byte array).
	 * A rate of change is calculated in volume and added on to volume (float) to
	 * achieve fade effect.
	 * 
	 * @param sample the sample to apply filter to.
	 * @param offset the starting offset value in sample (byte array) which data is written to.
	 * @param length maximum number of bytes to read.
	 * @return length number of bytes buffer contains; -1 if end of stream reached.
	 */
	public int read(byte [] sample, int offset, int length) throws IOException {
		// Get the number of bytes in the data stream
		int 	bytesRead = super.read(sample,offset,length);
		int		p;			// Loop variable
		short 	amp = 0;	// The amplitude read from the sound sample
		short	val = 0;	// The value read from further down the sample array
		short	echoed = 0;	// The amplitude for the echoed sound

		int		delay = 10000;	// The delay for the echo (how long it takes the sound to bounce back
		int		delayed = 0;	// Position of the echoed delay in the 'sample' array

		//	Loop through the sample 2 bytes at a time
		for (p=0; p<bytesRead; p = p + 2) {
			// Get the value at the front of the sound buffer
			amp = getSample(sample,p);
			// Work out where to put the new echoed sound
			delayed = p + delay;
			if (delayed < bytesRead) {
				// Get the delayed value, add an echo to it
				short original = getSample(sample, delayed);
				// Apply echo - smaller fraction = less intense echo
				echoed = (short)((original+amp)/4);
				// Now put the new value back in the sample array.
				setSample(sample,delayed,echoed);
			}//end if
		}//endfor
		return length;
	}//end method read
}//end class EchoSound

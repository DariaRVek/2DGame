package game2D;

import java.io.*;

/**
 * Class to apply a fade filter to a sound.
 */
public class FadeSound extends FilterInputStream {

	/**
	 * Constructor method.
	 * 
	 * @param in the stream of bytes.
	 */
	FadeSound(InputStream in) { super(in); }

	/**
	 * Method taken from practical 5.
	 * Retrieves a value in buffer (byte array) at a given position (int).
	 * Converts value to short big-endian format.
	 * 
	 * @param buffer the byte array containing sound sample.
	 * @param position the position in buffer to retrieve sample from.
	 * @return value in buffer in short big-endian format.
	 */
	public short getSample(byte[] buffer, int position) {
		return (short) (((buffer[position+1] & 0xff) << 8) |
					     (buffer[position] & 0xff));
	}//end method getSample

	
	/**
	 * Method taken from practical 5.
	 * Sets sample (short) in buffer (byte array) at given position
	 * (int) in little-endian format.
	 * 
	 * @param buffer the byte array containing sound sample.
	 * @param position the position in buffer to set sample to.
	 * @param sample the sample to set.
	 */
	public void setSample(byte[] buffer, int position, short sample) {
		buffer[position] = (byte)(sample & 0xFF);
		buffer[position+1] = (byte)((sample >> 8) & 0xFF);
	}//end method setSample

	/**
	 * Method to iterate through a given sample and gradually increase its volume.
	 * A rate of change is calculated in volume and added on to volume (float) to
	 * achieve fade effect.
	 * 
	 * @param sample the sample to apply filter to.
	 * @param offset the starting offset value in sample (byte array) which data is written to.
	 * @param length maximum number of bytes to read.
	 * @return length number of bytes buffer contains; -1 if end of stream reached.
	 */
	public int read(byte [] sample, int offset, int length) throws IOException {
		// Get the number of bytes in the data stream
		int bytesRead = super.read(sample,offset,length);
		// Work out a rate of change in volume per sample
		// (multiplied by 2 because we are move at 2 bytes per loop cycle)
		float change = 2.0f * (1.0f / (float)bytesRead);
		// Start volume at 0.05 (almost silent)
		float volume = 0.05f;
		short amp=0;

		//	Loop through the sample 2 bytes at a time
		for (int p=0; p<bytesRead; p = p + 2) {
			// Read the current amplitutude (volume)
			amp = getSample(sample,p);
			// Reduce it by the relevant volume factor
			amp = (short)((float)amp * volume);
			// Set the new amplitude value
			setSample(sample,p,amp);
			// Increase the volume
			volume = volume + change;
		}//endfor
		return length;

	}//end method read
}//end class FadeSound

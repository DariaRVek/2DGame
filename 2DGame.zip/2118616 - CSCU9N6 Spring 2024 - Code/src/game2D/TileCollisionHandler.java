package game2D;

import java.awt.Color;
import java.awt.Graphics2D;
import java.util.ArrayList;

/**
 * A class intended to handle tile collisions.
 * Currently not in use.
 */
public class TileCollisionHandler {
	
	private ArrayList<Tile> collidedTiles = new ArrayList<Tile>();
	private boolean levelComplete = false;
	private boolean gameOver = false;
	
	public TileCollisionHandler(boolean levelComplete, boolean gameOver) {
		this.levelComplete = levelComplete;
		this.gameOver = gameOver;
	}
	
	public void drawCollidedTiles(Graphics2D g, TileMap map, int xOffset, int yOffset)
    {
		if (collidedTiles.size() > 0)
		{	
			int tileWidth = map.getTileWidth();
			int tileHeight = map.getTileHeight();
			
			g.setColor(Color.blue);
			for (Tile t : collidedTiles)
			{
				g.drawRect(t.getXC()+xOffset, t.getYC()+yOffset, tileWidth, tileHeight);
			}
		}
    }
	
    /**
     * Check and handles collisions with a tile map for the
     * given sprite 's'. Method also checks for specific tiles
     * such as coins, spikes, water, and end of level flag through
     * supplying argument 'true'.
     * 
     * @param s			The Sprite to check collisions for
     * @param tmap		The tile map to check 
     */
	public void checkTileCollision(Sprite s, TileMap tmap,
			int total, long elapsed) {
		// Empty out our current set of collided tiles
        collidedTiles.clear();
        Sound coin = new Sound("sounds/Pickup_Coin.wav", false, false);
        
        // Take a note of a sprite's current position and dimensions
        float sx = s.getX();
        float sy = s.getY();
        
    	// Find out how wide and how tall a tile is
    	float tileWidth = tmap.getTileWidth();
    	float tileHeight = tmap.getTileHeight();
    	
    	checkTopLeft(sx, sy, tileWidth, tileHeight, tmap, true, coin, total,s);
    	checkBottomLeft(sx, sy, tileWidth, tileHeight, tmap, true, coin, total,s);
    	checkMidLeft(sx, sy, tileWidth, tileHeight, tmap, true, coin, total,s);
    	checkTopRight(sx, sy, tileWidth, tileHeight, tmap, true, coin, total, s);
    	checkBottomRight(sx, sy, tileWidth, tileHeight, tmap, true, coin, total, s); 
        checkMidRight(sx, sy, tileWidth, tileHeight, tmap, true, coin, total, s);
	}
	
	/*============================= LEFT SIDE CHECKS =============================*/
	
	/**
	 * Method to check for tile collisions at top left of Sprite.
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of the Tile
	 * @param tileHeight the height of the Tile
	 * @param coin 
	 * @param s
	 */
    public void checkTopLeft(float sx, float sy, float tileWidth, float tileHeight, 
    		TileMap tmap, boolean check, Sound coin, int total, Sprite s) {
    	//TOP-LEFT CORNER
    	// Divide the sprite’s x coordinate by the width of a tile, to get
    	// the number of tiles across the x axis that the sprite is positioned at 
    	int xTile = (int)(sx / tileWidth);
    	// The same applies to the y coordinate
    	int yTile = (int)(sy / tileHeight);
    	
    	//Tile at top left of Sprite
    	Tile tl = tmap.getTile(xTile, yTile);
    	
    	//level 1 contains different tile characters. if check is true, it will check for coins, spikes,
    	//water, and flag collisions.
    	if (tl != null && tl.getCharacter() != '.') // If it's not a dot (empty space), handle it
    	{
    		if(check==true) {
    			if(tl.getCharacter() == 'w') {
    	    		coin.start();
    	    		total = total + 100;
    	    		tmap.setTileChar('.', xTile, yTile);
    	    	}if (tl.getCharacter() == 'B') {
        			levelComplete = true;
        		} else if (tl.getCharacter() == 'g' || tl.getCharacter() == 'x') {
        			gameOver = true;
        		}
    		} 
    		float newY = tl.getYC() - s.getHeight();
    		s.setPosition(sx, newY); 
    		s.stop();
    		collidedTiles.add(tl);
    	} 
    }//end method checkTopLeft
    
    public void checkBottomLeft(float sx, float sy, float tileWidth, float tileHeight, 
    		TileMap tmap, boolean check, Sound coin, int total, Sprite s) {
    	//BOTTOM-LEFT CORNER
    	// We need to consider the other corners of the sprite
    	// The above looked at the top left position, let's look at the bottom left.
    	int xtile = (int)(sx / tileWidth);
    	int ytile = (int)((sy + s.getHeight()) / tileHeight);
    	Tile bl = tmap.getTile(xtile, ytile);
    	
    	// If it's not empty space
     	if (bl != null && bl.getCharacter() != '.') 
    	{
     		float newY = bl.getYC() - s.getHeight();
    		s.setPosition(sx, newY);
    		// Let's make the sprite bounce
    		//s.setVelocityY(-s.getVelocityY()*0.6f); // Reverse velocity 
    		s.stop();
    		collidedTiles.add(bl);
     		if(check==true) {
     			if(bl.getCharacter() == 'w') {
    	    		coin.start();
    	    		total = total + 100;
    	    		tmap.setTileChar('.', xtile, ytile);
    	    	}if (bl.getCharacter() == 'B') {
        			levelComplete = true;
        		} else if (bl.getCharacter() == 'g' || bl.getCharacter() == 'x') {
        			gameOver = true;
        		}
     		}
    	}
    }//end method checkBottomLeft
    
    public void checkMidLeft(float sx, float sy, float tileWidth, float tileHeight, 
    		TileMap tmap, boolean check, Sound coin, int total, Sprite s) {
    	//MID-LEFT
    	int xtile = (int)((sx / tileWidth));
    	int ytile = (int)(((sy + s.getHeight()/2) / tileHeight));
    	Tile ml = tmap.getTile(xtile, ytile);
    	if (ml != null && ml.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
    		s.stop();
        	s.setX((xtile+1)*tileWidth);
        	collidedTiles.add(ml);
    		if(check==true) {
    			if(ml.getCharacter() == 'w') {
    	    		coin.start();
    	    		total = total + 100;
    	    		tmap.setTileChar('.', xtile, ytile);
    	    	}if (ml.getCharacter() == 'B') {
        			levelComplete = true;
        		} else if (ml.getCharacter() == 'g' || ml.getCharacter() == 'x') {
        			gameOver = true;
        		}
    		}
    	}
    }//end method checkMidLeft
    
    /*============================= RIGHT SIDE CHECKS =============================*/
    public void checkTopRight(float sx, float sy, float tileWidth, float tileHeight, 
    		TileMap tmap, boolean check, Sound coin, int total, Sprite s) {
        // TOP-RIGHT CORNER
     	int xtile = (int)((sx + s.getWidth() / tileWidth));
     	int ytile = (int)((sy + s.getHeight()) / tileHeight);
        Tile tr = tmap.getTile(xtile, ytile);
     	if (tr != null && tr.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
     		if(check==true) {
	     		checkCoin(tr, coin, total, tmap, xtile, ytile);
	    		checkFlag(tr);
	    		checkGameover(tr);
     		}
     		float newY = tr.getYC() - s.getHeight();
    		s.setPosition(sx, newY);
    		s.stop();
    		collidedTiles.add(tr);
     	}
    }//end method checkTopRight
    
    public void checkBottomRight(float sx, float sy, float tileWidth, float tileHeight, 
    		TileMap tmap, boolean check, Sound coin, int total, Sprite s) {
    	// BOTTOM-RIGHT CORNER
     	int xtile = (int)((sx + s.getWidth()) / tileWidth);
     	int ytile = (int)((sy + s.getHeight()) / tileHeight);
        Tile br = tmap.getTile(xtile, ytile);
    	// If it's not empty space
     	if (br != null && br.getCharacter() != '.'){
     		if(check==true) {
	     		checkCoin(br, coin, total, tmap, xtile, ytile);
	    		checkFlag(br);
	    		checkGameover(br);
     		} 
     		float newY = br.getYC() - s.getHeight();
    		s.setPosition(sx, newY);
    		// Let's make the sprite bounce
    		//s.setVelocityY(-s.getVelocityY()*0.6f); // Reverse velocity
     		s.stop();
    		collidedTiles.add(br);		
    	}
    }//end method checkBottomRight
    
    public void checkMidRight(float sx, float sy, float tileWidth, float tileHeight, 
    		TileMap tmap, boolean check, Sound coin, int total, Sprite s) {
     	//MID-RIGHT
     	int xtile = (int)((sx + s.getWidth()) / tileWidth);
        int ytile = (int)((sy + s.getHeight()/2) / tileHeight);
        Tile mr = tmap.getTile(xtile, ytile);
    	// If it's not empty space
        if (mr != null && mr.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
        	if(check==true) {
        		checkCoin(mr, coin, total, tmap, xtile, ytile);
        		checkFlag(mr);
        		checkGameover(mr);
        	}	
	        	s.stop();
	        	s.setX((xtile+1)*tileWidth);
	        	collidedTiles.add(mr);
    	}
    }//end method checkMidRight
    
    /*============================= GAME STATE CHECKS =============================*/
	
    
    public void checkGameover(Tile t) {
    	checkSpike(t);
    	checkWater(t);
    }
    
    public void checkFlag(Tile t) {
    	if (t.getCharacter() == 'B') {
			levelComplete = true;
		}
    }
    
    public void checkSpike(Tile t) {
    	if (t.getCharacter() == 'x') {
    		gameOver = true;
		}
    }
    
    public void checkWater(Tile t) {
    	if (t.getCharacter() == 'g') {
    		gameOver = true;
		}
    }
	
	/**
	 * Method to handle tile collisions where Tile t is a coin.
	 */
	public void checkCoin(Tile t, Sound coin, int total, TileMap tmap, int xtile, int ytile) {
    	if(t.getCharacter() == 'w') {
    		coin.start();
    		total = total + 100;
    		tmap.setTileChar('.', xtile, ytile);
    	}
    }
}

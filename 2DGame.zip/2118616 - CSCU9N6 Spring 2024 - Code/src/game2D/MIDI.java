package game2D;

import java.io.File;
import java.io.IOException;

import javax.sound.midi.InvalidMidiDataException;
import javax.sound.midi.MetaEventListener;
import javax.sound.midi.MetaMessage;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Sequence;
import javax.sound.midi.Sequencer;
import javax.sound.midi.Synthesizer;

/**
 * @author 2118616
 * 
 * Class to play a MIDI file.
 */
public class MIDI extends Thread implements MetaEventListener{
	
	String filename; // The name of the file to play
	boolean finished; // A flag showing that the thread has finished
	Sequencer seq;
	
	/**
	 * Constructor method to create new MIDI object to play a MIDI file.
	 * 
	 * @param fname the name of the MIDI file to play.
	 */
	public MIDI(String fname) {
		filename = fname;
		finished = false;
	}//end constructor method
	
	/**
	 * Method to play a MIDI sound file.
	 */
	public void run() {
		try {
			// Get a reference to the MIDI data stored in the file
			Sequence score = MidiSystem.getSequence(new File(filename));
			// Get a reference to a sequencer that will play it
			seq = MidiSystem.getSequencer();
			// Open the sequencer and play the sequence (score)
			seq.open();			
			seq.addMetaEventListener(this);
			seq.setSequence(score);
		    // Adjusting volume for MIDI
		    if (seq instanceof Synthesizer) {
		        Synthesizer synthesizer = (Synthesizer) seq;
		        MidiChannel[] channels = synthesizer.getChannels();
		        for (MidiChannel channel : channels)
		            if (channel != null) channel.controlChange(7, 50); // Adjust volume (controller 7) to 10 (0-127)
		    }//end if seq instanceof Synthesizer
			seq.start();
		} catch(MidiUnavailableException m) {
			System.out.println("Can't play MIDI track. Error getting sequencer: " + m);
		} catch(InvalidMidiDataException i) {
			System.out.println("Can't play MIDI track. Error converting data - MIDI files only! " + i);
		} catch(NullPointerException n) {
			System.out.println("Can't play MIDI track. Error accessing file! " + n);
		} catch(IOException ioe) {
			System.out.println("Error occurred: " + ioe);
		}//end try catch
	}//end method run
	
	/**
	 * Method to stop MIDI track playing.
	 */
	public void stopTrack() {
		seq.stop();
		seq.close();
	}//end method stopTrack

	/**
	 * Method to listen for end of the track.
	 * Repeats track when we reach the end.
	 * 0x2F represents MIDI end of track event according
	 * to MIDI specification. Decimal value is 47.
	 */
	@Override
	public void meta(MetaMessage meta) {
		//0x2F (decimal 47) represents MIDI end of track event, according to MIDI specification.
		if(meta.getType()==47) { //if we reach the end of the track
			seq.setMicrosecondPosition(0); //set position to start of track
			seq.start(); //restart the track
		}//endif
	}//end method meta

}//end class MIDI

package game2D;

/**
 * A class intended to handle sprite to sprite collisions.
 * Currently not in use.
 */
public class SpriteCollisionHandler {
	
	/*
    public void handleEnemyCollision(Sprite s1, Sprite s2) {
    	Sound ouch = new Sound("sounds/ouch.wav");
    	if(boundingCircleCollision(s1, s2)) {    		
    		ouch.start();
    		collisionCount += 1;
    		if(collisionCount == 4) gameOver = true;
        	s1.setAnimation(hurt);
        	hearts.removeLast();
        	if(moveLeft || leftReleased ) { //player collided with enemy from right
        		s1.setX(s1.getPrevX() + s1.getWidth()*2);
		    	s1.setVelocityY(s1.getVelocityY()*0.75f);
		    	s1.setVelocityX(s1.getVelocityX()*0.75f);
        	} else { //player collided with enemy from the left
		    	s1.setX(s1.getPrevX() - s1.getWidth()*2);
		    	s1.setVelocityY(-s1.getVelocityY()*0.75f);
		    	s1.setVelocityX(-s1.getVelocityX()*0.75f);
        	}//endif
        } //endif
    }
	
	public void handlePowerUpCollision(Sprite s1, Sprite s2) {
		Sound gemPickup = new Sound("sounds/pickup_gem.wav");
		if(boundingCircleCollision(s1,s2) && (s1 == player)) {
			gemPickup.start();
			total = total + 1000;
			s2.hide();
		}
	}
	*/
	public boolean boundingCircleCollision(Sprite s1, Sprite s2) {
		//calculation from centre of sprite; not top left x,y
		int dx, dy, minimum;
		dx = (int) (s1.getX() - s2.getX());
		dy = (int)(s1.getY() - s2.getY());
		minimum = (int)(s1.getRadius() + s2.getRadius());
		return (((dx * dx) + (dy * dy)) < (minimum * minimum));
	}

    /** Use the sample code in the lecture notes to properly detect
     * a bounding box collision between sprites s1 and s2.
     * 
     * @return	true if a collision may have occurred, false if it has not.
     */
    public boolean boundingBoxCollision(Sprite s1, Sprite s2)
    { 
    	return (s1.getX() + s1.getImage().getWidth(null) > s2.getX()) &&
    			(s1.getX() < (s2.getX()+s2.getImage().getWidth(null))) &&
    			((s1.getY()+s1.getImage().getHeight(null) > s2.getY())) &&
    			(s1.getY() < s2.getY() + s2.getImage().getHeight(null));
    }

}

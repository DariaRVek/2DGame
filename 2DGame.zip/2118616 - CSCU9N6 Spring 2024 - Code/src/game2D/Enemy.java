package game2D;

/**
 * @author 2118616
 * 
 * Class extends Sprite to provide additional functionality typical of an "Enemy".
 */
public class Enemy extends Sprite {
	
	/*==================================CLASS VARIABLES==================================*/
	
	private int patrolRangeMin;
	private int patrolRangeMax;
	/*
	 * constant RANGE used to determine when 
	 * Enemy starts to chase player (RANGE number of pixels)
	 */
	private static final int RANGE = 250;

	/**
	 * Constructor method to create an Enemy.
	 * 
	 * @param anim the Animation to create this Enemy with.
	 */
	public Enemy(Animation anim) {
		super(anim);	
	}//end constructor method
	
	/*==================================PATROLLING AND CHASING==================================*/
	
	/**
	 * Method to move Enemy along a straight line within a range.
	 */
	public void patrol() {
		if(getX() <= getPatrolRangeMin()) setVelocityX(0.02f);//move right
        else if(getX() >= getPatrolRangeMax()) setVelocityX(-0.02f);//else move left
	}//end method patrol
	
	/**
	 * Method to pursue a Sprite s.
	 * If Sprite s is within RANGE (final int) number of pixels of this Enemy,
	 * Enemy will follow Sprite s and move faster.
	 * 
	 * @param s the Sprite to chase.
	 */
	public void chase(Sprite s) {
		float distanceX = Math.abs(s.getX() - getX());
    	float distanceY = Math.abs(s.getY() - getY());
    	//if player is within range, chase player
    	if(distanceX <= RANGE && (distanceY >= 0 && distanceY <=20)) { 
    			//if player is to the enemy's left
        		if(s.getX() < getX()) setVelocityX(-0.075f); //enemy chase to left
        		else setVelocityX(0.075f); //otherwise enemy chase to right	
    	} else patrol(); //else the player is not in distance. Enemy should patrol.	 
	}//end method chase
	
	/*==================================GETTERS AND SETTERS==================================*/
	
	/**
	 * Method to access patrolRangeMin.
	 * 
	 * @return patrolRangeMin.
	 */
	public int getPatrolRangeMin() { return patrolRangeMin; }
	
	/**
	 * Method to access patrolRangeMax.
	 * 
	 * @return patrolRangeMax.
	 */
	public int getPatrolRangeMax() { return patrolRangeMax; }
	
	/**
	 * Method to set the value of patrolRangeMin.
	 * 
	 * @param minPosition the minimum position which this Enemy will patrol from.
	 */
	public void setPatrolRangeMin(int minPosition) { 
		patrolRangeMin = minPosition;
	}//end method setPatrolRangeMin
	
	/**
	 * Method to set the value of patrolRangeMax.
	 * 
	 * @param maxPosition the maximum position which this Enemy will patrol to.
	 */
	public void setPatrolRangeMax(int maxPosition) { 
		patrolRangeMax = maxPosition;
	} //end method setPatrolRangeMax
	
	/**
	 * Method to set this Enemy's patrol range.
	 * 
	 * @param min the minimum X coordinate from which this Enemy will patrol.
	 * @param max the maximum X coordinate to which this Enemy will patrol.
	 */
	public void setPatrolRange(int min, int max) {
		setPatrolRangeMin(min);
		setPatrolRangeMax(max);
	}//end method setPatrolRange

}//end class Enemy

package game2D;

import java.io.*;

import javax.sound.midi.Sequencer;
import javax.sound.sampled.*;

/**
 * Class to play an audio file.
 */
public class Sound extends Thread {

	String filename;	// The name of the file to play
	boolean finished;	// A flag showing that the thread has finished
	Sequencer seq;
	FloatControl volControl;
	boolean hasFadeFilter;
	boolean hasEchoFilter;
	
	/**
	 * Constructor method to create new Sound object to play an audio file.
	 * 
	 * @param fname the name of the sound file to play.
	 * @param hasFadeFilter boolean specifying if fade effect should be applied.
	 * @param hasEcho boolean specifying if echo effect should be applied.
	 */
	public Sound(String fname, boolean hasFadeFilter, boolean hasEcho) {
		filename = fname;
		finished = false;
		this.hasFadeFilter = hasFadeFilter;
		this.hasEchoFilter = hasEcho;
	}//end constructor method

	/**
	 * run will play the actual sound but you should not call it directly.
	 * You need to call the 'start' method of your sound object (inherited
	 * from Thread, you do not need to declare your own). 'run' will
	 * eventually be called by 'start' when it has been scheduled by
	 * the process scheduler.
	 */
	public void run() {
		try {
			Clip clip;
			File file = new File(filename);
			AudioInputStream stream = AudioSystem.getAudioInputStream(file);
			AudioFormat	format = stream.getFormat();
			if(hasFadeFilter) { //apply fade effect
				FadeSound faded = new FadeSound(stream);
				AudioInputStream f = new AudioInputStream(faded,format,stream.getFrameLength());
				DataLine.Info info = new DataLine.Info(Clip.class, format);
				clip = (Clip)AudioSystem.getLine(info);
				clip.open(f);
			} else if (hasEchoFilter) { //apply echo effect
				EchoSound echoed = new EchoSound(stream);
				AudioInputStream f = new AudioInputStream(echoed,format,stream.getFrameLength());
				DataLine.Info info = new DataLine.Info(Clip.class, format);
				clip = (Clip)AudioSystem.getLine(info);
				clip.open(f);
			} else { //otherwise just play sound as normal
				DataLine.Info info = new DataLine.Info(Clip.class, format);
				clip = (Clip)AudioSystem.getLine(info);
				clip.open(stream);
			}//end if

			//adjust volume
			//volControl = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
			//setVolume(-20.0f);
			
			clip.start();			
			Thread.sleep(100);
			while (clip.isRunning()) { Thread.sleep(100); }
			clip.close();
		} catch (Exception e) {	}
		
		finished = true;

	}//end method run
	
    /**
     * Method to allow for volume adjustment.
     * 
     * @param volume the new volume level.
     */
    public void setVolume(float volume) {
        if (volControl != null) volControl.setValue(volume);       
    }//end method setVolume
	
}//end class Sound

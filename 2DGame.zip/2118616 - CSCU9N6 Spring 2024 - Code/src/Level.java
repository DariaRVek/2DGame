
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import game2D.*;

/**
 * @author 2118616
 * 
 * Class Level defines instance fields and methods common to
 * all Levels. Class is abstract as more details are needed
 * to construct a complete Level.
 */
@SuppressWarnings("serial")
public abstract class Level extends GameCore {
	
	/*==================================CLASS VARIABLES==================================*/
	
	// Game constants
	protected static int screenWidth = 750;
	protected static int screenHeight = 595;

	// Game constants
	protected float lift = 0.005f;
	protected float	gravity = 0.0001f;
	protected float	upSpeed = -0.04f;
	protected float	moveSpeed = 0.2f;
    
    // Game state flags
	protected boolean moveUp = false;
	protected boolean moveRight = false;
	protected boolean moveLeft = false;
	protected boolean leftReleased = false;
	protected boolean debug = true;
	protected boolean gameOver = false;
	protected boolean levelComplete = false;
	protected boolean spriteAtLeft = false;
	protected boolean spriteAtRight = false;

    //Game resources
	protected Animation idle, run, hurt;
	protected Sprite player = null;
	protected LinkedList<Sprite> bgLayers = new LinkedList<Sprite>();
	protected ArrayList<Sprite> pickups = new ArrayList<Sprite>(); //gems, cherries etc. 
	protected ArrayList<Enemy> enemies = new ArrayList<Enemy>();
	protected LinkedList<Sprite> hearts = new LinkedList<Sprite>(); //level starts with 4 hearts. Enemy collision removes a heart.
	protected ArrayList<Sprite>	clouds = new ArrayList<Sprite>(); //David's clouds :)
	protected ArrayList<Tile> collidedTiles = new ArrayList<Tile>(); //tiles a sprite has collided with.

	protected TileMap tmap = new TileMap(); //the tilemap which the player Sprite interacts with
	protected MIDI bgTrack; //MIDI track playing on loop
    
	protected long total; //the points a player has gained.
	protected long collisionCount = 0; //number of enemy collisions. If 4, gameOver flips to true.
    
	
	/*==================================INITIALISATION METHODS==================================*/
	
	
	/**
	 * Method to initialise various components of a Level.
	 * 
	 * @param folder the folder containing the tile map.
	 * @param mapname the name of the tile map.
	 */
	public void initLevel(String folder, String mapname) {
    	backgroundTrack();
    	initWorld(folder, mapname);    	
    	setSize(screenWidth, tmap.getPixelHeight());
        setVisible(true);        
        initBackground(); //abstract - implemented in subclasses
        initPlayer();
        initEnemies(); //abstract - implemented in subclasses
        initPickups(); //abstract - implemented in subclasses
        initHealthStatus();
        initClouds();
        initialiseGame();		
        System.out.println(tmap);
        setLocationRelativeTo(null);
    }//end method initLevel
	
	/**
	 * Method to initialise and play background track.
	 */
    protected void backgroundTrack() {
    	bgTrack = new MIDI("sounds/mymidi3.mid");     	
    	try { bgTrack.start(); } 
    	catch (Exception e) { e.printStackTrace(); } 
    }//end method backgroundTrack
    
    /**
     * Method to initialise the player Sprite.
     * Also loads in all animations used throughout the game.
     * Default player animation is idle.
     */
	protected void initPlayer() {
    	idle = new Animation();
        idle.loadAnimationFromSheet("images/player_idle.png", 4, 1, 100);
        player = new Sprite(idle);
        
        run = new Animation();
        run.loadAnimationFromSheet("images/player_run.png", 6, 1, 50);
        
        hurt = new Animation();
        hurt.loadAnimationFromSheet("images/player_hurt.png", 2, 1, 50);       
    }//end method initPlayer
	
	/**
	 * Method to initialise 4 hearts.
	 * Positioned to top right of screen.
	 * If player collides with a sprite, a 
	 * heart will be removed from the List.
	 */
	protected void initHealthStatus() {
    	Animation ha = new Animation();
        ha.addFrame(loadImage("images/heart.png"), 1000);
        Sprite heart;
        int x = screenWidth-100;
        for(int i = 0; i < 4; i++) {
        	heart = new Sprite(ha);
        	heart.setPosition(x, 80);
        	x+=20; //move next heart along
        	heart.show();
        	hearts.add(heart);
        }//end for
    }//end method initHealthStatus
	
	/**
	 * Method to create 3 cloud Sprites.
	 * Retained from assignment starter code.
	 */
	protected void initClouds() {
    	// Load a single cloud animation
        Animation ca = new Animation();
        ca.addFrame(loadImage("images/cloud.png"), 1000);
        Sprite s;	// Temporary reference to a sprite
        // Create 3 clouds at random positions off the screen
        // to the right
        for (int c=0; c<3; c++) {
        	s = new Sprite(ca);
        	s.setX(screenWidth + (int)(Math.random()*200.0f));
        	s.setY(30 + (int)(Math.random()*150.0f));
        	s.setVelocityX(-0.02f);
        	s.show();
        	clouds.add(s);
        }//endfor
    }//end method initClouds

	 /**
     * You will probably want to put code to restart a game in
     * a separate method so that you can call it when restarting
     * the game when the player loses.
     * NOTE: If the player loses, they are presented with the
     * "Level Select" screen (MainMenu), so the user can replay the level
     * if they wish, or they can try another level.
     */
    protected void initialiseGame() {
    	total = 0;
        player.setPosition(50,200);
        player.setVelocity(0,0);
        player.show();
    }//end method initialiseGame
    

	/*==================================DRAW METHODS==================================*/
    
    
    /**
     * Method to draw output to the screen via the
     * Graphics2D object g. 
     * 
     * @param g the Graphics2D object to draw with.
     */
	@Override
	public void draw(Graphics2D g) {
		int xo = -(int)player.getX() + 50;
        int yo = 0;
        g.setColor(Color.white);
        g.fillRect(0, 0, getWidth(), getHeight());
        drawBackground(xo, yo, g);
        drawClouds(xo, yo, g); 
        drawWorld(g, xo, yo); //abstract - implemented in subclasses
        drawPlayer(xo, yo, g);
        drawPickups(xo, yo, g);
        drawEnemies(xo, yo, g);
        displayScore(g);     
        if(debug) debugDraw(g, xo, yo);
	}//end method draw
	
	/**
	 * Method to draw background to screen.
	 * This method can handle varying numbers of background layers.
	 * Each background layer is stored in class member bgLayers (LinkedList).
	 * While the bgX value is less than the width of the window, it will
	 * set the offsets for the current background layer, draw it to screen,
	 * then update bgX so that it moves to the next position to draw the current
	 * background at. The bgX value is reset on exiting the while loop in
	 * readiness for the next layer.
	 * 
	 * @param xo the x-offset value to shift the view by.
	 * @param yo the y-offset value to shift the view by.
	 * @param g the Graphics2D object to draw with.
	 */
    protected void drawBackground(int xo, int yo, Graphics2D g) {
		int bgX = xo;
		for(int i = 0; i<bgLayers.size(); i++) {
			while(bgX < getWidth()) {
				bgLayers.get(i).setOffsets(bgX, yo);
				bgLayers.get(i).draw(g);
				bgX += bgLayers.get(i).getWidth();
			}//end while
			bgX = xo;
		}//end for
	}//end method drawBackground
	
    /**
     * Method to draw clouds to screen.
     * Retained from assignment starter code.
     * 
     * @param xo the x-offset value to shift the view by.
	 * @param yo the y-offset value to shift the view by.
	 * @param g the Graphics2D object to draw with.
     */
	protected void drawClouds(int xo, int yo, Graphics2D g) {
        // Apply offsets to sprites then draw them
        for (Sprite s: clouds) {
        	s.setOffsets(xo,yo);
        	s.draw(g);
        }//endfor
	}//end method drawClouds
	
	/**
	 * Method to draw player Sprite to screen.
	 * Uses overloaded method drawTransformed which will draw
	 * the player Sprite according to player's movement direction.
	 * If player is moving left (moveLeft), or its last movement 
	 * was leftwards (leftReleased), then the player Sprite's scale 
	 * and width is set to negative. See drawTransformed in Sprite.java.
	 * 
	 * @param xo the x-offset value to shift the view by.
	 * @param yo the y-offset value to shift the view by.
	 * @param g the Graphics2D object to draw with.
	 */
    protected void drawPlayer(int xo, int yo, Graphics2D g) {
        // Apply offsets to player and draw 
        player.setOffsets(xo, yo);
        player.setScale(1);
        player.drawTransformed(g, moveLeft, leftReleased);
    }//end method drawPlayer
    
    /**
     * Method to draw "pickup" Sprites to screen.
     * A pickup is any Sprite that will add to the
     * player's total score. For every Sprite in the
     * List pickups, offset values are set and each Sprite
     * is then drawn to screen.
     * 
     * @param xo the x-offset value to shift the view by.
	 * @param yo the y-offset value to shift the view by.
	 * @param g the Graphics2D object to draw with.
     */
    protected void drawPickups(int xo, int yo, Graphics2D g) {
    	for(Sprite pickup : pickups) {
    		pickup.setOffsets(xo, yo);
    		pickup.draw(g);
        }//end for
    }//end method drawPickups
    
    /**
     * Method to draw enemy Sprites to screen.
     * Class Enemy extends Sprite, making methods
     * setOffsets and drawTransformed available.
     * The Enemy is drawn to screen using another overloaded
     * drawTransformed method. It achieves the same effect
     * as the drawTransformed method used to draw the player
     * Sprite to screen, but takes a float value as an argument.
     * This method will set the Enemy's scale and width to negative
     * if its x-velocity is >= 0.
     * 
     * @param xo the x-offset value to shift the view by.
	 * @param yo the y-offset value to shift the view by.
	 * @param g the Graphics2D object to draw with.
     */
	protected void drawEnemies(int xo, int yo, Graphics2D g) {
		for(Enemy e : enemies) {
        	e.setOffsets(xo, yo);
        	e.drawTransformed(g, e.getVelocityX());
        }//end for
	}//end method drawEnemies
      
	/**
	 * Method to show player's score.
	 * 
	 * @param g the Graphics2D object to draw with.
	 */
    protected void displayScore(Graphics2D g) {
        // Show score and status information
        String msg = String.format("Score: %d", total);
        g.setColor(Color.red);
        g.drawString(msg, getWidth() - 100, 50);
        for(Sprite s : hearts) s.draw(g); 
    }//end method displayScore
    
    /**
     * Method to draw borders around Level's objects.
     * A border is drawn around the main tile map, the player,
     * all Enemies, all pickup Sprites, the player's position,
     * and collided tiles.
     * 
     * @param g the Graphics2D object to draw with.
     * @param xo the y-offset value to shift the view by.
     * @param yo the y-offset value to shift the view by.
     */
	protected void debugDraw(Graphics2D g, int xo, int yo) {
		tmap.drawBorder(g, xo, yo, Color.black);
        g.setColor(Color.green);
        player.drawBoundingBox(g);
        g.setColor(Color.red);
        player.drawBoundingCircle(g);
    	g.setColor(Color.yellow);
    	for(Sprite p : enemies)  {
    		p.drawBoundingCircle(g);
    		p.drawBoundingBox(g);
    	}
    	g.setColor(Color.orange);
    	for(Sprite s : pickups) s.drawBoundingCircle(g);   	
    	g.drawString(String.format("Player: %.0f,%.0f", player.getX(),player.getY()),
    								getWidth() - 100, 70);   	
    	drawCollidedTiles(g, tmap, xo, yo);
	}//end method debugDraw
	
	/**
	 * Method to draw a border around tiles in List collidedTiles.
	 * Invoked in debugDraw method.
	 * 
	 * @param g the Graphics2D object to draw with.
	 * @param map the tile map containing the tiles which have been collided with.
	 * @param xOffset the y-offset value to shift the view by.
	 * @param yOffset the y-offset value to shift the view by.
	 */
	protected void drawCollidedTiles(Graphics2D g, TileMap map, int xOffset, int yOffset) {
		if (collidedTiles.size() > 0) {	
			int tileWidth = map.getTileWidth();
			int tileHeight = map.getTileHeight();			
			g.setColor(Color.blue);
			for (Tile t : collidedTiles)
				g.drawRect(t.getXC()+xOffset, t.getYC()+yOffset, tileWidth, tileHeight);
		}//end if
    }//end method drawCollidedTiles

	
	/*==================================UPDATE METHODS==================================*/
	
	
	/**
	 * Method to override update method in GameCore.java.
	 * Method will update the state of the game and/or animations
	 * based on the amount of elapsed time that has passed.
	 * Some updates are left to subclasses to allow for flexibility.
	 * This method will continually update game objects. It will
	 * take care of the player hitting the edges of the screen, and will
	 * check for collisions that may result in gamestate switching to
	 * gameOver or levelComplete.
	 * 
	 * @param elapsed the amount of time that has elapsed since its last call.
	 */
	@Override
	public void update(long elapsed) {
		updatePlayer(elapsed);
		updateBackground(elapsed); //abstract - implemented in subclasses
		updateClouds(elapsed);
		updatePickups(elapsed); //abstract - implemented in subclasses
		updateEnemies(elapsed);
		//Now check for collisions
		handleScreenEdge(player, tmap, elapsed);
		checkTileCollision(player, tmap, elapsed); //abstract - implemented in subclasses
		checkGameOver(elapsed);
		checkLevelComplete(levelComplete, elapsed);
	}//end method update
	
	/**
	 * Method to update state of the player sprite.
	 * Changes to behaviour take place in this method.
	 * For example, if the player is moving, the Sprite's animation changes.
	 * @param elapsed the amount of time elapsed since this method was last called.
	 */
	protected void updatePlayer(long elapsed) {
        player.setVelocityY(player.getVelocityY()+(gravity*elapsed));   	
       	player.setAnimationSpeed(1.0f);
       	if (moveUp) {
       		player.setAnimationSpeed(1.8f);
       		player.setVelocityY(upSpeed);
       	}//end if moveUp      	
       	if (moveRight) {
       		player.setAnimation(run);
       		player.setVelocityX(moveSpeed);
       	} else if (moveLeft) {
       		player.setAnimation(run);
       		player.setVelocityX(-moveSpeed); //travel to left
       	} else if (gameOver){
       		player.setAnimation(hurt);
       		player.stop();
       	}
       	else {      	
       		player.setAnimation(idle);
       		player.setVelocityX(0);
       	}//end if else if else
       	player.update(elapsed);
	}//end method updatePlayer
	
	/**
	 * Method to update the clouds.
	 * Retained from assignment starter code.
	 * 
	 * @param elapsed the amount of time elapsed since this method was last called.
	 */
    protected void updateClouds(long elapsed) {
       	for (Sprite s: clouds) s.update(elapsed);
    }//end method updateClouds

    /**
     * Method to update Enemy Sprites.
     * Iterates through enhanced for loop so all Enemies
     * continually patrol and pursue the player Sprite if
     * player comes within certain range of Enemy.
     * 
     * @param elapsed the amount of time elapsed since this method was last called.
     */
	protected void updateEnemies(long elapsed) {
    	for(Enemy e : enemies) {
    		//checkTileCollision(e, tmap, elapsed);
    		e.chase(player);
        	handleSpriteCollision(player, e);
        	e.update(elapsed);
        }//end for
    }//end method updateEnemies
	
	/**
     * Checks and handles collisions with the edge of the screen. You should generally
     * use tile map collisions to prevent the player leaving the game area. This method
     * is only included as a temporary measure until you have properly developed your
     * tile maps.
     * 
     * NOTE: Method used primarily for handling the player hitting left and right
     * screen edges. Tile collision for bottom implemented, but this looked better
     * during testing for left and right edges.
     * 
     * @param s			The Sprite to check collisions for
     * @param tmap		The tile map to check 
     * @param elapsed	How much time has gone by since the last call
     */
	protected void handleScreenEdge(Sprite s, TileMap tmap, long elapsed){
    	//handleBottomEdge taken from assignment starter code.
		//Retained for good measure. Tile collision implemented also.
    	handleBottomEdge(s, tmap, elapsed);
    	handleRightEdge(s, tmap, elapsed);
    	handleLeftEdge(s, elapsed);
    }//end method handleScreenEdge
	
	/**
	 * Method to check and handle collisions with the bottom edge of the screen.
	 * Retained from assignment starter code.
	 * 
	 * @param s the Sprite to check collisions for.
	 * @param tmap the tile map to check.
	 * @param elapsed the amount of time elapsed since this method was last called.
	 */
	protected void handleBottomEdge(Sprite s, TileMap tmap, long elapsed) {
		// This method just checks if the sprite has gone off the bottom screen.
    	// Ideally you should use tile collision instead of this approach
		float difference = s.getY() + s.getHeight() - tmap.getPixelHeight();
        if (difference > 0){
        	// Put the player back on the map according to how far over they were
        	s.setY(tmap.getPixelHeight() - s.getHeight() - (int)(difference)); 
        	
        	// and make them bounce
        	s.setVelocityY(-s.getVelocityY()*0.75f);
        }//endif
	}//end method handleBottomEdge
	
	/**
	 * Method to check and handle collisions with the right edge of the screen.
	 * Prevents player from running outside of the right side game world.
	 * Sets class member boolean spriteAtRight to true if difference > 0.
	 * This boolean is used to control the movement of the background Sprites:
	 * if Sprite s is running and is at right edge of screen, the background should
	 * be still and not move at all. This boolean helps to control the bg movement.
	 * 
	 * @param s the Sprite to check collisions for.
	 * @param tmap the tile map to check.
	 * @param elapsed the amount of time elapsed since this method was last called.
	 */
	private void handleRightEdge(Sprite s, TileMap tmap, long elapsed) {
		float rightDifference = s.getX() + s.getWidth() - tmap.getPixelWidth();
        if(rightDifference > 0) {
        	spriteAtRight = true;
        	s.setX(tmap.getPixelWidth() - s.getWidth() - (int)(rightDifference));
        	s.setVelocityX(-s.getVelocityX()*0.75f);
        }//endif
	}//end method handleRightEdge
	
	/**
	 * Method to check and handle collisions with the right edge of the screen.
	 * Prevents player from running outside of the left side game world.
	 * Sets class member boolean spriteAtLeft to true if difference <= 0.
	 * This boolean is used to control the movement of the background Sprites:
	 * if Sprite s is running and is at left edge of screen, the background should
	 * be still and not move at all. This boolean helps to control the bg movement.
	 * 
	 * @param s the Sprite to check collisions for.
	 * @param elapsed the amount of time elapsed since this method was last called.
	 */
	private void handleLeftEdge(Sprite s, long elapsed) {
		float leftDifference = s.getX();
        if(leftDifference <= 0) {
        	spriteAtLeft = true;
        	s.setX(0);
        	s.setVelocityX(-s.getVelocityX()*0.75f);
        }//end if
	}//end method handleLeftEdge

	/**
	 * Method to check if game status gameOver is true.
	 * If gameOver is true, the background track stops, gameover sound
	 * starts, then game pauses briefly before presenting the Main 
	 * Menu ("Level Select").
	 * 
	 * @param gameOver boolean value representing game state. 
	 * @param elapsed the amount of time elapsed since this method was last called.
	 */
	protected void checkGameOver(long elapsed) {
    	Sound gameover = new Sound("sounds/gameover.wav", false, false); //false = no filter
    	if(gameOver) {
    		//stop the background track
    		bgTrack.stopTrack();
    		gameover.start();
    		try {
				Thread.sleep(2500); //wait before transition to MainMenu
				this.dispose();
				MainMenu home = new MainMenu();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}//end try catch
    	}//end if gameOver
    }//end method checkGameOver
	
	/**
	 * Method to check if game status levelComplete is true.
	 * If levelComplete is true, the background track stops, levelComplete
	 * sound starts, then game pauses briefly before presenting the Main 
	 * Menu ("Level Select").
	 * 
	 * @param lvlComplete boolean value representing game state.
	 * @param elapsed the amount of time elapsed since this method was last called.
	 */
	protected void checkLevelComplete(boolean lvlComplete, long elapsed) {
    	Sound levelComplete = new Sound("sounds/level-complete.wav", true, false); //true = fade filter applied
    	if(lvlComplete) {
    		System.out.println("Level complete: " + lvlComplete);
    		bgTrack.stopTrack();
    		levelComplete.start();
    		try {
    			Thread.sleep(2500); //wait before transition to MainMenu
    			this.dispose();
    			MainMenu home = new MainMenu();
    		} catch (InterruptedException e) {
				e.printStackTrace();
			}//end try catch
    	}//end if lvlComplete
    }//end method checkLevelComplete
	

	/*==================================COLLISION DETECTION METHODS==================================*/

	
	/**
	 * Method to check for Sprite to Sprite collisions using a bounding circle.
	 * Used to detect an initial collision.
	 * 
	 * @param s1 the Sprite to check.
	 * @param s2 the other Sprite to check.
	 * @return true if Sprites' bounding circles intersect; false otherwise.
	 */
	protected boolean boundingCircleCollision(Sprite s1, Sprite s2) {
		//calculation from centre of sprite; not top left x,y
		int dx, dy, minimum;
		dx = (int) (s1.getX() - s2.getX());
		dy = (int)(s1.getY() - s2.getY());
		minimum = (int)(s1.getRadius() + s2.getRadius());
		return (((dx * dx) + (dy * dy)) < (minimum * minimum));
	}//end method boundingCircleCollision
	
	/**
	 * Method to first check if there is an initial collision between two Sprites.
	 * If initial collision suspected, test performed on smaller circles; otherwise
	 * method returns false so resources not wasted on performing unnecessary
	 * calculations.
	 * 
	 * @param s1 the Sprite to check.
	 * @param s2 the other Sprite to check.
	 * @return true if a refined collision is detected; false otherwise.
	 */
	protected boolean refinedBoundingCircleCollision(Sprite s1, Sprite s2) {
		if(boundingCircleCollision(s1, s2)) {
			//calc new radius
			int smallerRadius = (int)(Math.min(s1.getRadius(), s2.getRadius()) * 0.5);
			//calc distance between centres
			int dx = (int)(s1.getX() - s2.getX());
			int dy = (int)(s1.getY() - s2.getY());
			int dist = (int)Math.sqrt(dx*dx + dy*dy);
			//refined collision detected?
			if(dist < smallerRadius *2) return true;
			//else no refined collision has been detected
			else return false;
			//no initial collision detected? return false
		} else return false;
	}//end method boundingCircleCollision

    /** Use the sample code in the lecture notes to properly detect
     * a bounding box collision between sprites s1 and s2.
     * 
     * @return	true if a collision may have occurred, false if it has not.
     */
	protected boolean boundingBoxCollision(Sprite s1, Sprite s2) { 
    	return (s1.getX() + s1.getImage().getWidth(null) > s2.getX()) &&
    			(s1.getX() < (s2.getX()+s2.getImage().getWidth(null))) &&
    			((s1.getY()+s1.getImage().getHeight(null) > s2.getY())) &&
    			(s1.getY() < s2.getY() + s2.getImage().getHeight(null));
    }//end method boundingBoxCollision
	
	/**
	 * Simple method to check if a Tile t is character 'B'.
	 * This represents a flag which if a player collides with,
	 * indicates the level is complete.
	 * 
	 * @param t the Tile to check.
	 */
	protected void checkFlag(Tile t) {
    	if (t.getCharacter() == 'B') levelComplete = true;
    }//end method checkFlag
	
	
	/*==================================COLLISION HANDLING METHODS==================================*/
	
	
	/**
	 * Method to handle a Sprite to Sprite collision.
	 * Intended for player to enemy collisions.
	 * Checks for collisions using refinedBoundingCircleCollision, which
	 * will return false if no initial collision is detected, so as to 
	 * avoid wasting computational power.
	 * 
	 * @param s1 the Sprite to check.
	 * @param s2 the other Sprite to check.
	 */
	protected void handleSpriteCollision(Sprite s1, Sprite s2) {
    	Sound ouch = new Sound("sounds/ouch.wav", false, false); //false = no filter
    	if(refinedBoundingCircleCollision(s1, s2)) {  
    		ouch.start();
    		collisionCount += 1;
    		if(collisionCount == 4) gameOver = true;
    		s1.setAnimation(hurt);
        	hearts.removeLast();
        	if(moveLeft || leftReleased) { //player collided with enemy from right
        		s1.setX(s1.getPrevX() + s1.getWidth()*2);
		    	s1.setVelocityY(s1.getVelocityY()*0.75f);
		    	s1.setVelocityX(s1.getVelocityX()*0.75f);
        	} else { //player collided with enemy from the left
		    	s1.setX(s1.getPrevX() - s1.getWidth()*2);
		    	s1.setVelocityY(-s1.getVelocityY()*0.75f);
		    	s1.setVelocityX(-s1.getVelocityX()*0.75f);
        	}//endif
        } //endif
    }//end method handleSpriteCollision

	/**
	 * Method to deal with a single sprite s1 colliding with another sprite s2 where
	 * Sprite s2 is an element of a List and where Sprite s2 should be removed.
	 * Flexible as to what sound effect is played.
	 * Intended for Sprite player to Sprite pickup collisions.
	 * Calls standard boundingCircleCollision method to minimise user frustration.
	 * 
	 * @param soundEffect the sound to play when collision detected.
	 * @param s1 the Sprite colliding with Sprite s2.
	 * @param sprites the List of Sprites to check. 
	 * @param index the index of the Sprite's position in the List.
	 * @param pointValue the points value of Sprite s2.
	 */
	protected void handleSpriteCollision(String soundEffect, Sprite s1, List<Sprite> sprites, int index, int pointValue) {
    	Sound sound = new Sound(soundEffect, false, false);
    	if(boundingCircleCollision(s1, sprites.get(index))) {
    		sound.start();
    		total = total + pointValue;
    		sprites.remove(index);
    	}//end if
    }//end method handleSpriteCollision
    

	/*==================================INPUT HANDLER METHODS==================================*/
    
	
	/*
	 * Controls are the same throughout the game, so these are defined here and
	 * inherited by each subclass such as Level1, Level2 etc.
	 */
	
    /**
     * Override of the keyPressed event defined in GameCore to catch our
     * own events
     * 
     * @param e The event that has been generated
     */
	@Override
    public void keyPressed(KeyEvent e) { 
    	int key = e.getKeyCode();
    	
		switch (key) {
			case KeyEvent.VK_UP : 
				moveUp = true; 
				break;
			case KeyEvent.VK_RIGHT : 
				//Sound runSound = new Sound("sounds/run_sound.wav", false, true); //true = echo applied
				//runSound.start();
				moveRight = true; 
				moveLeft = false; //we can't move right and left at the same time
				leftReleased = false;
				break;
			case KeyEvent.VK_LEFT : 
				//Sound run = new Sound("sounds/run_sound.wav", false, true); //true = echo applied
				//run.start();
				moveLeft = true; 
				moveRight = false; //we can't move left and right at the same time
				leftReleased = false;
				break;
			case KeyEvent.VK_ESCAPE : 
				stop(); 
				break;
			case KeyEvent.VK_B : 
				debug = !debug; //Flip the debug state
				break; 
			default : break;
		}//end switch
    }//end method keyPressed
    
    /**
     * Override of keyReleased method defined in GameCore.
     * 
     * @param e the event that has been generated (user released a key).
     */
	@Override
	public void keyReleased(KeyEvent e) { 
		int key = e.getKeyCode();
		switch (key) {
			case KeyEvent.VK_ESCAPE : 
				stop(); 
				break;
			case KeyEvent.VK_UP :
				moveUp = false; 
				break;
			case KeyEvent.VK_RIGHT  : 
				moveRight = false; //key released = not moving
				leftReleased = false; 
				moveLeft = false;
				break;
			case KeyEvent.VK_LEFT : 
				leftReleased = true;
				moveRight = false;
				moveLeft = false; 
				break;
			default : break;
		}//end switch
	}//end method keyReleased    
    
	
    /*==================================ABSTRACT METHODS==================================*/
    
	
    /* 
     * The following methods have been made abstract to allow flexibility.
     * Each level will likely have a different world with different objects. 
     * This will allow subclasses to define their own enemies, backgrounds,
     * tile maps etc. 
     */
    protected abstract void initWorld(String folder, String mapname); //tile map(s)
    protected abstract void initBackground(); //background layers (number of layers varies between levels)
    protected abstract void initPickups(); //gems, cherries etc.
    protected abstract void initEnemies(); //possums, green things etc.
    
    /*
     * Levels can have varying numbers of tilemaps, so drawWorld 
     * is abstract to allow individual Levels to decide how to draw the game world.
     */
    protected abstract void drawWorld(Graphics2D g, int xo, int yo);
    
    /*
     * There may be differences in updates depending on what type
     * of pickup the player has collided with. Making this
     * method abstract can, for example, allow for different sound effects.
     * These methods are abstract to allow for flexibility.
     */
    protected abstract void updatePickups(long elapsed);
    protected abstract void updateBackground(long elapsed);

    /*
     * Some levels may use the same characters in their tilemaps, but
     * such characters may represent completely different tiles.
     * This method is abstract so each Level can decide how to handle
     * tile collisions.
     */
    protected abstract void checkTileCollision(Sprite s, TileMap tmap, long elapsed);
}//end class Level

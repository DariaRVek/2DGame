import java.awt.Graphics2D;

import game2D.*;

/**
 * @author 2118616
 * 
 * Class represents one individual Level in the game (Level 1).
 */
@SuppressWarnings("serial")
public class Level1 extends Level {
	
	/*==================================CLASS VARIABLES==================================*/
	
	private Animation bgLayer1, bgLayer2, bgLayer3, bgLayer4, bgLayer5;
    private Sprite bgL1=null, bgL2=null, bgL3 = null, bgL4 = null, bgL5=null;
   
    /**
     * Constructor method to construct this Level.
     * Specifies the tile map to use for this level.
     */
    public Level1() {
    	initLevel("maps", "level1.txt");;
		run(false, screenWidth, screenHeight);
    }//end constructor method
    
    
    /*==================================INITIALISATION METHODS==================================*/
	
   
    /**
     * Method to load the tile map for Level 1.
     * 
     * @param folder the folder containing the main tile map.
     * @param mapname the name of the main tile map.
     */
	@Override
	protected void initWorld(String folder, String mapname) {
		tmap.loadMap(folder, mapname);
	}//end method initWorld
	
	/**
	 * Method to initialise the background in this Level.
	 * This Level contains 5 background layers.
	 * Each layer is added to the List of Sprites bgLayers.
	 */
	@Override
	protected void initBackground() {
		bgLayer1 = new Animation();
        bgLayer1.addFrame(loadImage("images/background1/1.png"), 1000);
        bgL1 = new Sprite(bgLayer1);
        bgLayers.add(bgL1);
        bgLayer2 = new Animation();
        bgLayer2.addFrame(loadImage("images/background1/2.png"), 1000);
        bgL2 = new Sprite(bgLayer2);
        bgLayers.add(bgL2);
        bgLayer3 = new Animation();
        bgLayer3.addFrame(loadImage("images/background1/3.png"), 1000);
        bgL3 = new Sprite(bgLayer3);
        bgLayers.add(bgL3);
        bgLayer4 = new Animation();
        bgLayer4.addFrame(loadImage("images/background1/4.png"), 1000);
        bgL4 = new Sprite(bgLayer4);
        bgLayers.add(bgL4);
        bgLayer5 = new Animation();
        bgLayer5.addFrame(loadImage("images/background1/5.png"), 1000);
        bgL5= new Sprite(bgLayer5);
        bgLayers.add(bgL5);
	}//end method initBackground

	/**
	 * Method to initialise any pickups in this Level.
	 * Level 1 uses gems (Sprites) as objects that will increase
	 * the player's score if the player collides with them.
	 */
	@Override
	protected void initPickups() {
		Animation g = new Animation();
        g.loadAnimationFromSheet("images/gem.png", 5, 1, 500);
        Sprite gem;
        int gemX = 815;
        for(int i = 0; i < 5; i++) {
        	gem = new Sprite(g);
        	gem.setPosition(gemX, 240);
        	gemX += 25;
        	gem.show();
        	pickups.add(gem);
        }//end for
	}//end method initPickups
	
	/**
	 * Method to initialise any Enemies in this Level.
	 * This level contains possums as Enemies.
	 */
	@Override
	protected void initEnemies() {
		Animation p = new Animation();
        p.loadAnimationFromSheet("images/enemy_possum.png", 6, 1, 100);
        Enemy poss;
        int possumStartX = 810;
        int possumStartY = 230;
        
        for(int i = 1; i < 3; i++) {   	
        	poss = new Enemy(p);
        	poss.setPosition(possumStartX, possumStartY);
        	poss.setPatrolRange(possumStartX-20, possumStartX+125);
        	poss.setVelocityX(0.1f);
        	possumStartX += 595; //move the next Enemy along
        	possumStartY += 64;//move the next Enemy down
        	poss.show();
        	enemies.add(poss);
        }//endfor
	}//end method initEnemies
	
	
	/*==================================DRAW METHODS==================================*/
	
	
	/**
	 * Method to draw the tile map to screen.
	 * 
	 * @param g the Graphics2D object to draw with.
	 * @param xothe x-offset value to shift the view by.
	 * @param yo the y-offset value to shift the view by.
	 */
	@Override
	protected void drawWorld(Graphics2D g, int xo, int yo) {
		tmap.draw(g, xo, yo);
	}//end method drawWorld
	

	/*==================================UPDATE METHODS==================================*/
	

	/**
	 * Method to update any pickups in this level.
	 * Uses a sound effect for gems and assigns pointValue 1000 to each gem.
	 *
	 * @param elapsed the amount of time that has elapsed since its last call.
	 */
	@Override
	protected void updatePickups(long elapsed) {
        for(int i = 0; i < pickups.size(); i++) 
        	handleSpriteCollision("sounds/pickup_gem.wav", player, pickups, i, 1000);
        
        for(Sprite gem : pickups) gem.update(elapsed);       
	}//end method updatePickups

	/**
	 * Method to update the state of each background layer.
	 * Each layer will move at a different speed.
	 * It uses boolean flags to determine its movement direction.
	 * If the player is moving right, the bg layer has a negative X velocity.
	 * If the player is moving left, the bg layer has a positive value.
	 * 
	 * @param elapsed the amount of time that has elapsed since its last call.
	 */
	@Override
	protected void updateBackground(long elapsed) {
		if(moveRight && !spriteAtRight) {
			bgL2.setVelocityX(-0.005f);
			bgL3.setVelocityX(-0.007f);
			bgL4.setVelocityX(-0.009f);
			bgL5.setVelocityX(-0.01f);
		} else if (moveLeft && !spriteAtLeft) {
			bgL2.setVelocityX(0.05f);
			bgL3.setVelocityX(0.07f);
			bgL4.setVelocityX(0.09f);
			bgL5.setVelocityX(0.1f);
		} else {
			bgL2.setVelocityX(0);
			bgL3.setVelocityX(0);
			bgL4.setVelocityX(0);
			bgL5.setVelocityX(0);
		}
		bgL1.update(elapsed);
       	bgL2.update(elapsed);
       	bgL3.update(elapsed);
       	bgL4.update(elapsed);
       	bgL5.update(elapsed);
	}//end method updateBackground
	
	
	/*==================================TILE COLLISION METHODS==================================*/
	

	/**
	 * Method to control routine of checking for tile collisions.
	 * Called in method update in Level.java. First clears the List
	 * of collided tiles, and checks collisions at 6 points around each tile.
	 * If a collision with a 'coin' tile is detected, a specific sound
	 * is played.
	 * 
	 * @param s the Sprite to check.
	 * @param tmap the tile map to check.
	 */
	@Override
	protected void checkTileCollision(Sprite s, TileMap tmap, long elapsed) {
		// Empty out our current set of collided tiles
        collidedTiles.clear();
        Sound coin = new Sound("sounds/Pickup_Coin.wav", false, false); //false = no filter
        
        // Take a note of a sprite's current position and dimensions
        float sx = s.getX();
        float sy = s.getY();
        
    	// Find out how wide and how tall a tile is
    	float tileWidth = tmap.getTileWidth();
    	float tileHeight = tmap.getTileHeight();
    	
    	checkTopLeft(sx, sy, tileWidth, tileHeight, coin, s);
    	checkBottomLeft(sx, sy, tileWidth, tileHeight, coin, s);
    	checkMidLeft(sx, sy, tileWidth, tileHeight, coin, s);
    	checkTopRight(sx, sy, tileWidth, tileHeight, coin, s);
    	checkBottomRight(sx, sy, tileWidth, tileHeight, coin, s); 
        checkMidRight(sx, sy, tileWidth, tileHeight, coin, s);
	}//end method checkTileCollision

	/**
	 * Method to check the tile at the top left corner of Sprite s.
	 * Method checks for special tiles (e.g. coins and spikes).
	 * If no "bad" tile collisions, then Sprite s is repositioned.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param coin the sound effect to be played if Sprite collides with a coin tile.
	 * @param s the Sprite to check.
	 */
    public void checkTopLeft(float sx, float sy, float tileWidth, float tileHeight, Sound coin, Sprite s) {
    	//TOP-LEFT CORNER
    	// Divide the sprite’s x coordinate by the width of a tile, to get
    	// the number of tiles across the x axis that the sprite is positioned at 
    	int xtile = (int)(sx / tileWidth);
    	// The same applies to the y coordinate
    	int ytile = (int)(sy / tileHeight);
    	
    	// What tile character is at the top left of the sprite s?
    	Tile tl = tmap.getTile(xtile, ytile);
    	if (tl != null && tl.getCharacter() != '.') // If it's not a dot (empty space), handle it
    	{
    		float newY = tl.getYC() + tileHeight;
    		s.setPosition(sx, newY); 
    		//s.stop();
    		collidedTiles.add(tl);
    		if(s==player) {    			
	    		if(isFlag(tl)) levelComplete = true;
	    		if(isSpike(tl)) gameOver = true;
	    		if(isWater(tl)) gameOver = true;
	    		if(isCoin(tl)) {
	    			increaseScore(100);
	    			replaceCoin(coin, xtile, ytile);
	    		}
    		}//end if s==player
    	}//end if
    }//end method checkTopLeft
    
    /**
	 * Method to check the tile at the bottom left corner of Sprite s.
	 * Method checks for special tiles (e.g. coins and spikes).
	 * If no "bad" tile collisions, then Sprite s is repositioned.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param coin the sound effect to be played if Sprite collides with a coin tile.
	 * @param s the Sprite to check.
	 */
    public void checkBottomLeft(float sx, float sy, float tileWidth, float tileHeight, Sound coin, Sprite s) {
    	//BOTTOM-LEFT CORNER
    	int xtile = (int)(sx / tileWidth);
    	int ytile = (int)((sy + s.getHeight()) / tileHeight);
    	Tile bl = tmap.getTile(xtile, ytile);
    	// If it's not empty space
     	if (bl != null && bl.getCharacter() != '.') {
     		float newY = bl.getYC() - s.getHeight();
     		//s.stop();
    		s.setPosition(sx, newY);
    		collidedTiles.add(bl);
    		if(s==player) {			
	     		if(isFlag(bl)) levelComplete = true;
	     		if(isSpike(bl)) gameOver = true;
	    		if(isWater(bl)) gameOver = true;
	    		if(isCoin(bl)) {
	    			increaseScore(100);
	    			replaceCoin(coin, xtile, ytile);
	    		} 
    		}//end if s==player
    	}//end if
    }//end method checkBottomLeft
    
    /**
	 * Method to check the tile positioned at Sprite's mid-left.
	 * Method checks for special tiles (e.g. coins and spikes).
	 * If no "bad" tile collisions, then Sprite s is repositioned.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param coin the sound effect to be played if Sprite collides with a coin tile.
	 * @param s the Sprite to check.
	 */
    public void checkMidLeft(float sx, float sy, float tileWidth, float tileHeight, Sound coin, Sprite s) {
    	//MID-LEFT
    	int xtile = (int)((sx / tileWidth));
    	int ytile = (int)(((sy + s.getHeight()/2) / tileHeight));
    	Tile ml = tmap.getTile(xtile, ytile);
    	if (ml != null && ml.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
    		//s.stop();
    		s.setX((xtile+1)*tileWidth);
    		collidedTiles.add(ml);
    		if(s==player) {  			
    			if(isFlag(ml)) levelComplete = true;
	    		if(isSpike(ml)) gameOver = true;
	    		if(isWater(ml)) gameOver = true;
	    		if(isCoin(ml)) {
	    			increaseScore(100);
	    			replaceCoin(coin, xtile, ytile);
	    		}
    		}//end if s==player
    	}//endif
    }//end method checkMidLeft
    
    /**
	 * Method to check the tile at the top right corner of Sprite s.
	 * Method checks for special tiles (e.g. coins and spikes).
	 * If no "bad" tile collisions, then Sprite s is repositioned.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param coin the sound effect to be played if Sprite collides with a coin tile.
	 * @param s the Sprite to check.
	 */
    public void checkTopRight(float sx, float sy, float tileWidth, float tileHeight, Sound coin, Sprite s) {
        // TOP-RIGHT CORNER
     	int xtile = (int)((sx + s.getWidth() / tileWidth));
     	int ytile = (int)((sy + s.getHeight()) / tileHeight);
        Tile tr = tmap.getTile(xtile, ytile);
     	if (tr != null && tr.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
     		float newY = tr.getYC() - tileHeight;
    		s.setPosition(sx, newY);
    		//s.stop();
    		collidedTiles.add(tr);
    		if(s==player) {    			
	     		if(isFlag(tr)) levelComplete = true;
	     		if(isSpike(tr)) gameOver = true;
	    		if(isWater(tr)) gameOver = true;
	    		if(isCoin(tr)) {
	    			increaseScore(100);
	    			replaceCoin(coin, xtile, ytile);
	    		} 
    		}//end if s==player
    	}//end if
    }//end method checkTopRight
    
    /**
	 * Method to check the tile positioned at Sprite's mid-left.
	 * Method checks for special tiles (e.g. coins and spikes).
	 * If no "bad" tile collisions, then Sprite s is repositioned.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param coin the sound effect to be played if Sprite collides with a coin tile.
	 * @param s the Sprite to check.
	 */
    public void checkBottomRight(float sx, float sy, float tileWidth, float tileHeight, Sound coin, Sprite s) {
    	// BOTTOM-RIGHT CORNER
     	int xtile = (int)((sx + s.getWidth()) / tileWidth);
     	int ytile = (int)((sy + s.getHeight()) / tileHeight);
        Tile br = tmap.getTile(xtile, ytile);
    	// If it's not empty space
     	if (br != null && br.getCharacter() != '.'){
     		float newY = br.getYC() - s.getHeight();
     		//s.stop();
    		s.setPosition(sx, newY);
    		collidedTiles.add(br);
    		if(s==player) {
    			
	    		if(isFlag(br)) levelComplete = true;
	     		if(isSpike(br)) gameOver = true;
	    		if(isWater(br)) gameOver = true;
	    		if(isCoin(br)) {
	    			increaseScore(100);
	    			replaceCoin(coin, xtile, ytile);
	    		} 	
    		}//end if s==player
    	}//endif
    }//end method checkBottomRight

    /**
	 * Method to check the tile at the top right corner of Sprite s.
	 * Method checks for special tiles (e.g. coins and spikes).
	 * If no "bad" tile collisions, then Sprite s is repositioned.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param coin the sound effect to be played if Sprite collides with a coin tile.
	 * @param s the Sprite to check.
	 */
    public void checkMidRight(float sx, float sy, float tileWidth, float tileHeight, Sound coin, Sprite s) {
     	//MID-RIGHT
     	int xtile = (int)((sx + s.getWidth()) / tileWidth);
        int ytile = (int)((sy + s.getHeight()/2) / tileHeight);
        Tile mr = tmap.getTile(xtile, ytile);
        if (mr != null && mr.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
        	//s.stop();
    		s.setX((xtile+1)*tileWidth);
    		collidedTiles.add(mr);
        	if(s==player) {      		
        		if(isFlag(mr)) levelComplete = true;
	        	if(isSpike(mr)) gameOver = true;
	    		if(isWater(mr)) gameOver = true;
	    		if(isCoin(mr)) {
	    			increaseScore(100);
	    			replaceCoin(coin, xtile, ytile);
	    		}
        	}//end if s==player
    	}//endif
    }//end method checkMidRight
    
    /**
     * Method to replace a coin character in tmap with a '.'.
     * 
     * @param coin the Sound to play.
     * @param xtile the x position of the tile to replace.
     * @param ytile the y position of the tile to replace.
     */
    public void replaceCoin(Sound coin, int xtile, int ytile) {
    	coin.start();
    	tmap.setTileChar('.', xtile, ytile);
    }//end method replaceCoin
    
    /**
     * Method to increase value of total.
     * 
     * @param increase the amount (int) to increase total by.
     */
    public void increaseScore(int increase) { total += increase; }
    
    /**
     * Method to check if Tile t is a "coin".
     * @param t the Tile to check.
     * @return true if tile character is 'w' (a coin); false otherwise.
     */
    public boolean isCoin(Tile t) {
    	if(t.getCharacter() == 'w') return true;
    	else return false;
    }//end method isCoin
    
	/**
	 * Method to check if a Tile t is character 'B'.
	 * Similar to method above but allows more control
	 * in tile collision handling.
	 * @param t
	 * @return
	 */
	protected boolean isFlag(Tile t) {
		if (t.getCharacter() == 'B') return true;
		else return false;
	}//end method isFlag
    
    /**
     * Method to check if Tile t is a "spike".
     * @param t the Tile to check.
     * @return true if tile character is 'x' (a spike); false otherwise.
     */
    public boolean isSpike(Tile t) {
    	if (t.getCharacter() == 'x') return true;
    	else return false;
    }//end method checkSpike
    
    /**
     * Method to check if Tile t is "water".
     * @param t the Tile to check.
     * @return true if tile character is 'g' (water); false otherwise.
     */
    public boolean isWater(Tile t) {
    	if (t.getCharacter() == 'g') return true;
    	else return false;
    }//end method checkWater
    
}//end class Level1

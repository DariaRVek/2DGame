/**
 * @author 2118616
 * 
 * Class to start the game.
 */
public class Launch {

    /**
	 * The obligatory main method that creates
     * an instance of our class and starts it running
     * 
     * @param args	The list of parameters this program might use (ignored)
     */
   public static void main(String[] args) {
        MainMenu home = new MainMenu();
   } //end method main

}//end class Launch



import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Random;

import game2D.*;

/**
 * @author 2118616
 * 
 * Class represents one individual Level in the game (Level 2).
 */
@SuppressWarnings("serial")
public class Level2 extends Level {
	
	/*==================================CLASS VARIABLES==================================*/
	
	Animation bgLayer1, bgLayer2, bgLayer3, bgLayer4, bgLayer5, bgLayer6, bgLayer7;
    Sprite bgL1=null, bgL2=null, bgL3 = null, bgL4 = null, bgL5=null, bgL6=null, bgL7=null;
    
    TileMap bgTmap = new TileMap(); //this level has 2 tile maps
    ArrayList<Sprite> gems = new ArrayList<Sprite>(); //this level has an additional type of pickup
    
    Random ra = new Random(); //to position some objects
    
    /**
     * Constructor method to construct this Level.
     * Specifies the tile map to use for this level.
     */
    public Level2() {
    	initLevel("maps", "level2.txt");
		run(false, screenWidth, screenHeight);
    }//end constructor method
    
    
    /*==================================INITIALISATION METHODS==================================*/
	
    
    /**
     * Method to load the tile map for Level 2.
     * This level has two tile maps.
     * 
     * @param folder the folder containing the main tile map.
     * @param mapname the name of the main tile map.
     */
	@Override
	protected void initWorld(String folder, String mapname) {
		bgTmap.loadMap("maps", "level2bg.txt");		
		tmap.loadMap(folder, mapname);
	}//end method initWorld

	/**
	 * Method to initialise the background in this Level.
	 * This Level contains 7 background layers.
	 * Each layer is added to the List of Sprites bgLayers.
	 */
	@Override
	protected void initBackground() {
        bgLayer1 = new Animation();
        bgLayer1.addFrame(loadImage("images/background2/city1.png"), 1000);
        bgL1 = new Sprite(bgLayer1);
        bgLayers.add(bgL1);
        bgLayer2 = new Animation();
        bgLayer2.addFrame(loadImage("images/background2/city2.png"), 1000);
        bgL2 = new Sprite(bgLayer2);
        bgLayers.add(bgL2);
        bgLayer3 = new Animation();
        bgLayer3.addFrame(loadImage("images/background2/city3.png"), 1000);
        bgL3 = new Sprite(bgLayer3);
        bgLayers.add(bgL3);
        bgLayer4 = new Animation();
        bgLayer4.addFrame(loadImage("images/background2/city4.png"), 1000);
        bgL4 = new Sprite(bgLayer4);
        bgLayers.add(bgL4);
        bgLayer5 = new Animation();
        bgLayer5.addFrame(loadImage("images/background2/city5.png"), 1000);
        bgL5= new Sprite(bgLayer5); 
        bgLayers.add(bgL5);
        bgLayer6 = new Animation();
        bgLayer6.addFrame(loadImage("images/background2/city7.png"), 1000);
        bgL6 = new Sprite(bgLayer6);
        bgLayers.add(bgL6);
        bgLayer7 = new Animation();
        bgLayer7.addFrame(loadImage("images/background2/city8.png"), 1000);
        bgL7 = new Sprite(bgLayer7);
        bgLayers.add(bgL7);
	}//end method initBackground

	/**
	 * Method to initialise any pickups in this Level.
	 * Level 2 uses gems (Sprites) and cherries (Sprites)
	 * as objects that will increase the player's score if 
	 * the player collides with them.
	 */
	@Override
	protected void initPickups() {
		initGems();
		initCherries();
	}//end method initPickups
	
	/**
	 * Method to initialise pickups in the form of gems.
	 * Called in initPickups.
	 */
	private void initGems() {
		Animation g = new Animation();
        g.loadAnimationFromSheet("images/gem.png", 5, 1, 500);
        Sprite gem;
        for(int i = 0; i < 5; i++) {
        	gem = new Sprite(g);
        	gem.setPosition(ra.nextInt(tmap.getPixelWidth())-50, ra.nextInt(tmap.getPixelHeight())-50);
        	gem.show();
        	gems.add(gem);
        }//end for 
	}//end method initGems
	
	/**
	 * Method to initialise pickups in the form of cherries.
	 * Called in initPickups.
	 */
	private void initCherries() {
        Animation cherryAnim = new Animation();
        cherryAnim.loadAnimationFromSheet("images/cherry.png", 7, 1, 2000);
        Sprite cherry;
        for(int i = 0; i < 25; i++) {
        	cherry = new Sprite(cherryAnim);
        	cherry.setPosition(ra.nextInt(tmap.getPixelWidth())-100, ra.nextInt(tmap.getPixelHeight())-200);
        	cherry.show();
        	pickups.add(cherry);
        }//end for
	}//end method initCherries
	
	/**
	 * Method to initialise any Enemies in this Level.
	 * This level contains "green things" as Enemies.
	 */
	@Override
	protected void initEnemies() {
		Animation e = new Animation();
        e.loadAnimationFromSheet("images/enemy_run.png", 12, 1, 150);
        Enemy enemy;
        int xPos = 50;
        int yPos = 241;
        for(int i = 1; i <= 5; i++) {
        	enemy = new Enemy(e);
        	enemy.setPosition(xPos, yPos);
        	enemy.setPatrolRange(xPos-20, xPos+125);
        	if(i%2==1) enemy.setVelocityX(0.1f);
        	else enemy.setVelocityX(-0.1f);
        	xPos += 200;
        	enemy.show();
        	enemies.add(enemy);
        }//end for 
	}//end method initEnemies
	
	
	/*==================================DRAW METHODS==================================*/
	
	
	/**
	 * Method to draw the tile maps to screen.
	 * 
	 * @param g the Graphics2D object to draw with.
	 * @param xothe x-offset value to shift the view by.
	 * @param yo the y-offset value to shift the view by.
	 */
	@Override
	protected void drawWorld(Graphics2D g, int xo, int yo) {
		tmap.draw(g, xo, yo);
		bgTmap.draw(g, xo, yo);
	}//end method drawWorld
	
	
	/*==================================UPDATE METHODS==================================*/
	

	/**
	 * Method to update state of any pickups in this level.
	 * Uses a sound effect for gems and assigns pointValue 1000 to each gem.
	 * Uses different sound effect for cherries, assigning pointValue 1500 to each cherry.
	 *
	 * @param elapsed the amount of time that has elapsed since its last call.
	 */
	@Override
	protected void updatePickups(long elapsed) {      
		updateGems(elapsed);
		updateCherries(elapsed);
	}//end method updatePickups
	
	/**
	 * Method to update state of any pickups in the form of gems in this level.
	 * @param elapsed the amount of time that has elapsed since its last call.
	 */
	private void updateGems(long elapsed) {
		for(int i = 0; i<gems.size(); i++) {
        	checkTileCollision(gems.get(i), tmap, elapsed);
        	handleSpriteCollision("sounds/pickup_gem.wav", player, gems, i, 1000);
        }//end for
		
        for(Sprite g : gems)
        	g.update(elapsed);
	}//end method updateGems
	
	/**
	 * Method to update state of any pickups in the form of cherries in this level.
	 * @param elapsed the amount of time that has elapsed since its last call.
	 */
	private void updateCherries(long elapsed) {
        for(int i = 0; i<pickups.size(); i++) {
        	//ensure cherries are not positioned behind a tile
        	checkTileCollision(pickups.get(i), tmap, elapsed);
        	handleSpriteCollision("sounds/pickup.wav", player, pickups, i, 1500);
        }//end for
        
        for(Sprite c : pickups) 
        	c.update(elapsed);
	}//end method updateCherries	

	/**
	 * Method to update the state of each background layer.
	 * Each layer will move at a different speed.
	 * The speed is calculated using the player's moveSpeed.
	 * It uses boolean flags to determine its movement direction.
	 * If the player is moving right, the bg layer has a negative X velocity.
	 * If the player is moving left, the bg layer has a positive value.
	 * 
	 * @param elapsed the amount of time that has elapsed since its last call.
	 */
	@Override
	protected void updateBackground(long elapsed) {
		if(moveRight) {
			bgL2.setVelocityX(-moveSpeed/10000f); //furthest away
			bgL3.setVelocityX(-moveSpeed/1000f);
			bgL4.setVelocityX(-moveSpeed/500f);
			bgL5.setVelocityX(-moveSpeed/250f);
			bgL6.setVelocityX(-moveSpeed/175f);
			bgL7.setVelocityX(-moveSpeed/5f); //nearest
		} else if (moveLeft) {
			bgL2.setVelocityX(moveSpeed/10000f); //furthest away
			bgL3.setVelocityX(moveSpeed/1000f);
			bgL4.setVelocityX(moveSpeed/500f);
			bgL5.setVelocityX(moveSpeed/250f);
			bgL6.setVelocityX(moveSpeed/175f);
			bgL7.setVelocityX(moveSpeed/5f); //nearest
		} else {
			bgL2.setVelocityX(0);
			bgL3.setVelocityX(0);
			bgL4.setVelocityX(0);
			bgL5.setVelocityX(0);
			bgL6.setVelocityX(0);
			bgL7.setVelocityX(0);
		}
		bgL1.update(elapsed);
       	bgL2.update(elapsed);
       	bgL3.update(elapsed);
       	bgL4.update(elapsed);
       	bgL5.update(elapsed);
       	bgL6.update(elapsed);
       	bgL7.update(elapsed);
	}//end method updateBackground
	
	
	/*==================================TILE COLLISION METHODS==================================*/
	

	/**
	 * Method to control routine of checking for tile collisions.
	 * Called in method update in Level.java. First clears the List
	 * of collided tiles, and checks collisions at 6 points around each tile.
	 * 
	 * @param s the Sprite to check.
	 * @param tmap the tile map to check.
	 */
	@Override
	protected void checkTileCollision(Sprite s, TileMap tmap, long elapsed) {
		// Empty out our current set of collided tiles
        collidedTiles.clear();
        
        // Take a note of a sprite's current position and dimensions
        float sx = s.getX();
        float sy = s.getY();
        
    	// Find out how wide and how tall a tile is
    	float tileWidth = tmap.getTileWidth();
    	float tileHeight = tmap.getTileHeight();
    	
    	checkTopLeft(sx, sy, tileWidth, tileHeight, s);
    	checkBottomLeft(sx, sy, tileWidth, tileHeight, s);
    	checkMidLeft(sx, sy, tileWidth, tileHeight, s);
    	checkTopRight(sx, sy, tileWidth, tileHeight, s);
    	checkBottomRight(sx, sy, tileWidth, tileHeight, s); 
        checkMidRight(sx, sy, tileWidth, tileHeight, s);	
	}//end method checkTileCollision
	
	/**
	 * Method to check the tile at the top left corner of Sprite s.
	 * Method checks for special tiles (i.e. flags) then repositions Sprite.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param s the Sprite to check.
	 */
	public void checkTopLeft(float sx, float sy, float tileWidth, float tileHeight, Sprite s) {
    	//TOP-LEFT CORNER
    	// Divide the sprite’s x coordinate by the width of a tile, to get
    	// the number of tiles across the x axis that the sprite is positioned at 
    	int xTile = (int)(sx / tileWidth);
    	// The same applies to the y coordinate
    	int yTile = (int)(sy / tileHeight);
    	
    	// What tile character is at the top left of the sprite s?
    	Tile tl = tmap.getTile(xTile, yTile);
    	
    	if (tl != null && tl.getCharacter() != '.') // If it's not a dot (empty space), handle it
    	{
    		checkFlag(tl);
    		float newY = tl.getYC() - s.getHeight();
    		s.setPosition(sx, newY);
    		s.stop();
    		collidedTiles.add(tl);
    	}//end if
    }//end method checkTopLeft
    
	/**
	 * Method to check the tile at the bottom left corner of Sprite s.
	 * Method checks for special tiles (i.e. flags) then repositions Sprite.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param s the Sprite to check.
	 */
    public void checkBottomLeft(float sx, float sy, float tileWidth, float tileHeight, Sprite s) {
    	//BOTTOM-LEFT CORNER
    	int xtile = (int)(sx / tileWidth);
    	int ytile = (int)((sy + s.getHeight()) / tileHeight);
    	Tile bl = tmap.getTile(xtile, ytile);
    	
    	// If it's not empty space
     	if (bl != null && bl.getCharacter() != '.') 
    	{
     		checkFlag(bl);
     		float newY = bl.getYC() - s.getHeight();
    		s.setPosition(sx, newY);
    		// Let's make the sprite bounce
    		//s.setVelocityY(-s.getVelocityY()*0.6f); // Reverse velocity 
    		s.stop();
    		collidedTiles.add(bl);
    	}//endif
    }//end method checkBottomLeft
    
	/**
	 * Method to check the tile positioned at Sprite's mid-left.
	 * Method checks for special tiles (i.e. flags) then repositions Sprite.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param s the Sprite to check.
	 */
    public void checkMidLeft(float sx, float sy, float tileWidth, float tileHeight, Sprite s) {
    	//MID-LEFT
    	int xtile = (int)((sx / tileWidth));
    	int ytile = (int)(((sy + s.getHeight()/2) / tileHeight));
    	Tile ml = tmap.getTile(xtile, ytile);
    	if (ml != null && ml.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
    		checkFlag(ml);
    		s.stop();
    		s.setX((xtile+1)*tileWidth);
    		collidedTiles.add(ml);
    	}//endif
    }//end method checkMidLeft
    
	/**
	 * Method to check the tile at the top right corner of Sprite s.
	 * Method checks for special tiles (i.e. flags) then repositions Sprite.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param s the Sprite to check.
	 */
    public void checkTopRight(float sx, float sy, float tileWidth, float tileHeight, Sprite s) {
        // TOP-RIGHT CORNER
     	int xtile = (int)((sx + s.getWidth() / tileWidth));
     	int ytile = (int)((sy + s.getHeight()) / tileHeight);
        Tile tr = tmap.getTile(xtile, ytile);
     	if (tr != null && tr.getCharacter() != '.'){ // If it's not a dot (empty space), handle it
     		checkFlag(tr);
     		float newY = tr.getYC() - s.getHeight();
    		s.setPosition(sx, newY);
    		s.stop();
    		collidedTiles.add(tr);
    	}//end if
    }//end method checkTopRight
    
	/**
	 * Method to check the tile at the bottom right corner of Sprite s.
	 * Method checks for special tiles (i.e. flags) then repositions Sprite.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param s the Sprite to check.
	 */
    public void checkBottomRight(float sx, float sy, float tileWidth, float tileHeight, Sprite s) {
    	// BOTTOM-RIGHT CORNER
     	int xtile = (int)((sx + s.getWidth()) / tileWidth);
     	int ytile = (int)((sy + s.getHeight()) / tileHeight);
        Tile br = tmap.getTile(xtile, ytile);
    	// If it's not empty space
     	if (br != null && br.getCharacter() != '.'){
     		checkFlag(br);
     		float newY = br.getYC() - s.getHeight();
    		s.setPosition(sx, newY);
    		// Let's make the sprite bounce
    		//s.setVelocityY(-s.getVelocityY()*0.6f); // Reverse velocity
     		s.stop();
    		collidedTiles.add(br);
    	}//endif
    }//end method checkBottomRight

	/**
	 * Method to check the tile positioned at Sprite's mid-right.
	 * Method checks for special tiles (i.e. flags) then repositions Sprite.
	 * 
	 * @param sx the Sprite's X coordinate.
	 * @param sy the Sprite's Y coordinate.
	 * @param tileWidth the width of a tile used to calculate number of 
	 * tiles across x-axis that sprite is positioned at.
	 * @param tileHeight the height of a tile used to calculate number of
	 * tiles down y-axis the sprite is positioned at.
	 * @param s the Sprite to check.
	 */
    public void checkMidRight(float sx, float sy, float tileWidth, float tileHeight, Sprite s) {
     	//MID-RIGHT
     	int xtile = (int)((sx + s.getWidth()) / tileWidth);
        int ytile = (int)((sy + s.getHeight()/2) / tileHeight);
        Tile mr = tmap.getTile(xtile, ytile);
    	// If it's not empty space
        if (mr != null && mr.getCharacter() != '.'){ // If it's not a dot (empty space), handle it	
        	checkFlag(mr);
        	s.stop();
    		s.setX((xtile+1)*tileWidth);
    		collidedTiles.add(mr);
    	}//endif
    }//end method checkMidRight

}//end class Level2
